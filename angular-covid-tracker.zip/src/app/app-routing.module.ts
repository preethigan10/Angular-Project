import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DistrictWiseComponent } from './district-wise/district-wise.component';

import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
  },
  { path: 'district/:code', component: DistrictWiseComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
