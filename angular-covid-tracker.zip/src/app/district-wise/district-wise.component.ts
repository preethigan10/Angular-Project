import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { ActivatedRoute } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-district-wise',
  templateUrl: './district-wise.component.html',
  styleUrls: ['./district-wise.component.css'],
})
export class DistrictWiseComponent implements OnInit {
  displayedColumns = ['district', 'confirmed', 'recovered', 'deaths'];
  data1$ = [];
  districtData = [];
  statecode: any;
  dataSource: any;

  constructor(
    private dataService: DataService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.statecode = params.code;
    });
    this.dataService.getDistrictData().subscribe((item) => {
      for (var i in item) {
        this.districtData.push(item[i]);
      }
      this.districtData.forEach((data) => {
        if (data.statecode === this.statecode) {
          const data1 = data.districtData;
          for (var i in data1) {
            data1[i].district = i;
            this.data1$.push(data1[i]);
          }
        }
      });
      this.dataSource = new MatTableDataSource<any>(this.data1$);
    });
  }
}
