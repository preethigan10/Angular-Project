import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  constructor(private readonly http: HttpClient) {}

  getData() {
    return this.http.get('https://data.covid19india.org/data.json');
  }

  getDistrictData() {
    return this.http.get(
      'https://data.covid19india.org/state_district_wise.json'
    );
  }
}
